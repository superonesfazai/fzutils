# coding:utf-8

'''
@author = super_fazai
@File    : url_utils.py
@Time    : 2016/7/28 11:59
@connect : superonesfazai@gmail.com
'''

"""
url parser
"""


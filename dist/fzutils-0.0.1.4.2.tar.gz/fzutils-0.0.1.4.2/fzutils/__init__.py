# coding:utf-8

'''
@author = super_fazai
@File    : __init__.py.py
@Time    : 2016/7/13 17:59
@connect : superonesfazai@gmail.com
'''

name = 'fzutils'